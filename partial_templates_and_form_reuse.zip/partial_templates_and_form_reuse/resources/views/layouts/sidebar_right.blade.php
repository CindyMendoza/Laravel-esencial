<div class="large-6 columns">
    <aside class="">
        <p><img src="http://placehold.it/300x440&text=[publicidad]"/></p>
    </aside>
</div>