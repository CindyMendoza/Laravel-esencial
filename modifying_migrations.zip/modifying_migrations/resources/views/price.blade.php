@extends('layouts.master')

@section('content')
<div class="row">
 
      <ul class="pricing-table">
        <li class="title">Standard</li>
        <li class="price">$99.99</li>
        <li class="description">An awesome description</li>
        <li class="bullet-item">1 Database</li>
        <li class="bullet-item">5GB Storage</li>
        <li class="bullet-item">20 Users</li>
        <li class="cta-button"><a class="button" href="#">Buy Now</a></li>
      </ul>
</div>
@stop